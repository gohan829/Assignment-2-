clear all; 
close all; 
clc

% Create the environment
Env = EnvironmentSetup();

% Define the axis limits for visualization
axis([-2.5 2.5 -2.5 2.5 -2.5 2.5])
view(3)
hold on;

% Define the starting transformation for r2 (translate by (0.9, -1, 0.05))
T_start_r2 = transl(0.9, -1, 0.05);  % Initial position for r2

% Initialize the second robot with the new base transformation
r2 = LinearUR3e2(T_start_r2);

% Define the starting transformation for r1 (translate by (0.9, 0, 0.05))
T_start_r1 = transl(0.9, 0, 0.05);  % Initial position for r1

% Initialize the first robot with the new base transformation
r1 = LinearUR3e(T_start_r1);

% Initialize grippers for both robots
gripper_r1 = GripperClass();  % Gripper for r1
gripper_r2 = GripperClass();  % Gripper for r2

% Update the base of the grippers to match the end-effector positions of r1 and r2
% r1's gripper base should be at the end-effector of r1
T_end_r1 = r1.model.fkine(r1.model.getpos());  % Get current end-effector pose of r1
gripper_r1.model.base = T_end_r1;  % Set gripper's base to match r1's end-effector

% r2's gripper base should be at the end-effector of r2
T_end_r2 = r2.model.fkine(r2.model.getpos());  % Get current end-effector pose of r2
gripper_r2.model.base = T_end_r2;  % Set gripper's base to match r2's end-effector

% Plot robots and grippers
r1.model.plot(r1.model.getpos());
r2.model.plot(r2.model.getpos());

gripper_r1.PlotAndColourRobot();  % Plot the gripper for r1
gripper_r2.PlotAndColourRobot();  % Plot the gripper for r2

